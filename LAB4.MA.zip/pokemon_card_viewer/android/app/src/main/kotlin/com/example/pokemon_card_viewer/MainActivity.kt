package com.example.pokemon_card_viewer

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
